
import 'package:flutter/material.dart';
import 'screens/home.dart';

void main() {
  runApp(const ShayariStudioApp());
}

class ShayariStudioApp extends StatelessWidget {
  const ShayariStudioApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shayari Studio',
      theme: ThemeData(brightness: Brightness.dark, primarySwatch: Colors.deepPurple),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
